using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Npgsql;

namespace exemplo
{
  public class Cliente
  {
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Endereco { get; set; }
    public string Telefone { get; set; }
    public string Documento { get; set; }







    public void CarregarCliente(int id)
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

      NpgsqlConnection connection = new
      NpgsqlConnection(connectionString);
      connection.Open();

      string sql = "SELECT * FROM cliente where id = " + id.ToString();
      NpgsqlCommand command = new NpgsqlCommand(sql, connection);

      command = new NpgsqlCommand(sql, connection);
      NpgsqlDataReader reader = command.ExecuteReader();
      while (reader.Read())
      {
        Id = reader.GetInt32(0);
        Nome = reader.GetString(1);
        Endereco = reader.GetString(2);
        Telefone = reader.GetString(3);
      }
      reader.Close();
      connection.Close();


    }







    public void ExcluirCliente(int id)
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

      NpgsqlConnection connection = new
      NpgsqlConnection(connectionString);
      connection.Open();

      string sql = "delete FROM cliente where id = " + id.ToString();
      NpgsqlCommand command = new NpgsqlCommand(sql, connection);

      command = new NpgsqlCommand(sql, connection);
      NpgsqlDataReader reader = command.ExecuteReader();

      reader.Close();
      connection.Close();


    }




    public void Salvardados()
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
      NpgsqlConnection connection = new NpgsqlConnection(connectionString);
      connection.Open();

      string sql = "INSERT INTO cliente(nome, endereco, telefone, documento) VALUES (@nome, @endereco, @telefone, @documento)";

      NpgsqlCommand command = new NpgsqlCommand(sql, connection);
      command.Parameters.AddWithValue("@nome", Nome);
      command.Parameters.AddWithValue("@endereco", Endereco);
      command.Parameters.AddWithValue("@telefone", Telefone);
      command.Parameters.AddWithValue("@documento", Documento);
      command.ExecuteNonQuery();

      connection.Close();
    }





    public void Alterardados()
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
      NpgsqlConnection connection = new NpgsqlConnection(connectionString);
      connection.Open();

      string sql = "UPDATE cliente SET nome=@nome, endereco=@endereco, telefone=@telefone, documento=@documento WHERE id=@id";

      NpgsqlCommand command = new NpgsqlCommand(sql, connection);
      command.Parameters.AddWithValue("@nome", Nome);
      command.Parameters.AddWithValue("@endereco", Endereco);
      command.Parameters.AddWithValue("@telefone", Telefone);
      command.Parameters.AddWithValue("@documento", Documento);
      command.Parameters.AddWithValue("@id", Id);
      command.ExecuteNonQuery();

      connection.Close();
    }







    public static List<Cliente> CarregarTodosClientes()
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
      List<Cliente> clientes = new List<Cliente>();

      using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
      {
        connection.Open();

        string sql = "SELECT * FROM cliente";
        using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
        {
          using (NpgsqlDataReader reader = command.ExecuteReader())
          {
            while (reader.Read())
            {
              Cliente cliente = new Cliente
              {
                Id = reader.GetInt32(0),
                Nome = reader.GetString(1),
                Endereco = reader.GetString(2),
                Telefone = reader.GetString(3)
              };
              clientes.Add(cliente);
            }
          }
        }
      }
      return clientes;
    }







    public static Cliente CarregarPorDocumento(string documento)
    {
      string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
      Cliente cliente = null;

      using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
      {
        connection.Open();

        string sql = "SELECT * FROM cliente WHERE documento = @documento";
        using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
        {
          command.Parameters.AddWithValue("@documento", documento);

          using (NpgsqlDataReader reader = command.ExecuteReader())
          {
            if (reader.Read())
            {
              cliente = new Cliente
              {
                Id = reader.GetInt32(0),
                Nome = reader.GetString(1),
                Endereco = reader.GetString(2),
                Telefone = reader.GetString(3),
                Documento = reader.GetString(4)
              };
            }
          }
        }
      }
      return cliente;
    }
  }
}