using Npgsql;

namespace exemplo
{
  public class Veiculo
  {
    public int Id { get; set; }
    public string Marca { get; set; }
    public string Modelo { get; set; }
    public int Ano { get; set; }
    public string Placa { get; set; }
    public string Chassi { get; set; }
    public string Proprietario { get; set; }
    public string Telefone { get; set; }

    private string conexao = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

    public void CarregarVeiculo(int id)
    {
      using (var con = new NpgsqlConnection(conexao))
      {
        con.Open();
        string sql = "SELECT v.*, c.nome, c.telefone FROM veiculo v " +
                     "INNER JOIN cliente c ON v.idcliente = c.id WHERE v.id = " + id;
        using (var cmd = new NpgsqlCommand(sql, con))
        {
          using (var reader = cmd.ExecuteReader())
          {
            if (reader.Read())
            {
              Id = reader.GetInt32(0);
              Marca = reader.GetString(1);
              Modelo = reader.GetString(2);
              Ano = reader.GetInt32(3);
              Placa = reader.GetString(4);
              Proprietario = reader.GetString(6);
              Telefone = reader.GetString(7);
            }
          }
        }
      }
    }

    public void ExcluirVeiculo(int id)
    {
      using (var con = new NpgsqlConnection(conexao))
      {
        con.Open();
        string sql = "DELETE FROM veiculo WHERE id = " + id;
        using (var cmd = new NpgsqlCommand(sql, con))
        {
          cmd.ExecuteNonQuery();
        }
      }
    }

    public void ExcluirVeiculoPorPlaca(string placa)
    {
      using (var con = new NpgsqlConnection(conexao))
      {
        con.Open();
        string sql = "DELETE FROM veiculo WHERE placa = @placa";
        using (var cmd = new NpgsqlCommand(sql, con))
        {
          cmd.Parameters.AddWithValue("@placa", placa);
          cmd.ExecuteNonQuery();
        }
      }
    }

    public void CadastrarVeiculo()
    {
      using (var con = new NpgsqlConnection(conexao))
      {
        con.Open();
        string sqlIdCliente = "SELECT id FROM cliente WHERE nome = @nome";
        int idCliente = 0;

        using (var cmdCliente = new NpgsqlCommand(sqlIdCliente, con))
        {
          cmdCliente.Parameters.AddWithValue("@nome", Proprietario);
          using (var reader = cmdCliente.ExecuteReader())
          {
            if (reader.Read())
            {
              idCliente = reader.GetInt32(0);
            }
            else
            {
              throw new Exception("Proprietário não encontrado.");
            }
          }
        }

        string sql = "INSERT INTO veiculo (marca, modelo, ano, placa, idcliente) VALUES " +
                     "(@marca, @modelo, @ano, @placa, @idcliente)";
        using (var cmd = new NpgsqlCommand(sql, con))
        {
          cmd.Parameters.AddWithValue("@marca", Marca);
          cmd.Parameters.AddWithValue("@modelo", Modelo);
          cmd.Parameters.AddWithValue("@ano", Ano);
          cmd.Parameters.AddWithValue("@placa", Placa);
          cmd.Parameters.AddWithValue("@idcliente", idCliente);
          cmd.ExecuteNonQuery();
        }
      }
    }

    public void AlterarVeiculo()
    {
      using (var con = new NpgsqlConnection(conexao))
      {
        con.Open();
        string sql = "UPDATE veiculo SET marca = @marca, modelo = @modelo, ano = @ano, placa = @placa WHERE id = @id";
        using (var cmd = new NpgsqlCommand(sql, con))
        {
          cmd.Parameters.AddWithValue("@marca", Marca);
          cmd.Parameters.AddWithValue("@modelo", Modelo);
          cmd.Parameters.AddWithValue("@ano", Ano);
          cmd.Parameters.AddWithValue("@placa", Placa);
          cmd.Parameters.AddWithValue("@id", Id);
          cmd.ExecuteNonQuery();
        }
      }
    }
  }
}
