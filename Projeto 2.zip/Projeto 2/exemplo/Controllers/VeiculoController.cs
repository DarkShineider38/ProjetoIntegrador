using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace exemplo.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class VeiculoController : ControllerBase
    {
        [HttpPost("cadastro")]
        public IActionResult Cadastrar([FromBody] Veiculo v)
        {
            try
            {
                v.CadastrarVeiculo();
                return Ok("Veículo cadastrado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao cadastrar: " + ex.Message);
            }
        }

        [HttpPut("alterar")]
        public IActionResult Alterar([FromBody] Veiculo v)
        {
            try
            {
                v.AlterarVeiculo();
                return Ok("Veículo alterado com sucesso!");
            }
            catch (Exception ex)
            {
                return BadRequest("Erro ao alterar: " + ex.Message);
            }
        }

        [HttpGet("buscar-por-nome")]
        public IActionResult BuscarPorNome([FromQuery] string nome)
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            List<Veiculo> veiculos = new List<Veiculo>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT v.id, v.marca, v.modelo, v.ano, v.placa, v.chassi, c.nome, c.telefone
            FROM veiculo v
            JOIN cliente c ON v.id_cliente = c.id
            WHERE LOWER(v.modelo) LIKE LOWER(@nome) OR LOWER(v.marca) LIKE LOWER(@nome);
        ";

                using (var command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("nome", $"%{nome}%");

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            veiculos.Add(new Veiculo
                            {
                                Id = reader.GetInt32(0),
                                Marca = reader.GetString(1),
                                Modelo = reader.GetString(2),
                                Ano = reader.GetInt32(3),
                                Placa = reader.GetString(4),
                                Chassi = reader.IsDBNull(5) ? null : reader.GetString(5),
                                Proprietario = reader.GetString(6),
                                Telefone = reader.GetString(7)
                            });
                        }
                    }
                }
            }

            return Ok(veiculos);
        }
        

        [HttpGet("todos")]
        public IActionResult ObterTodos()
        {
            string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
            List<Veiculo> veiculos = new List<Veiculo>();

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string sql = @"
            SELECT v.id, v.marca, v.modelo, v.ano, v.placa, v.chassi, c.nome, c.telefone
            FROM veiculo v
            JOIN cliente c ON v.id_cliente = c.id;
        ";

                using (var command = new NpgsqlCommand(sql, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        veiculos.Add(new Veiculo
                        {
                            Id = reader.GetInt32(0),
                            Marca = reader.GetString(1),
                            Modelo = reader.GetString(2),
                            Ano = reader.GetInt32(3),
                            Placa = reader.GetString(4),
                            Chassi = reader.IsDBNull(5) ? null : reader.GetString(5),
                            Proprietario = reader.GetString(6),
                            Telefone = reader.GetString(7)
                        });
                    }
                }
            }

            return Ok(veiculos);
        }
        [HttpDelete("por-id")]
        public IActionResult ExcluirPorId(int id)
        {
            try
            {
                var v = new Veiculo();
                v.ExcluirVeiculo(id);
                return Ok("Veículo excluído com sucesso!");
            }
            catch
            {
                return BadRequest("Erro ao excluir.");
            }
        }

    [HttpDelete("excluir")]
public IActionResult ExcluirVeiculo([FromQuery] int id, [FromQuery] string placa)
{
    int linhasAfetadas = 0;
    string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";

    using (var connection = new NpgsqlConnection(connectionString))
    {
        connection.Open();

        string sql = "DELETE FROM veiculo WHERE id = @id AND placa = @placa";

        using (var command = new NpgsqlCommand(sql, connection))
        {
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@placa", placa);

            linhasAfetadas = command.ExecuteNonQuery();
        }
    }

    if (linhasAfetadas > 0)
    {
        return Ok("Veículo excluído com sucesso.");
    }
    else
    {
        return NotFound("Nenhum veículo encontrado com o ID e placa informados.");
    }
}

    }
}