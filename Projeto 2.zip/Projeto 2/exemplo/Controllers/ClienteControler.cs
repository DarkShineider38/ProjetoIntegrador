using Microsoft.AspNetCore.Mvc;
using Npgsql;

namespace exemplo.Controllers;

[ApiController]
[Route("[controller]")]

public class ClienteController : ControllerBase
{

    private readonly ILogger<ClienteController> _logger;

    public ClienteController(ILogger<ClienteController> logger)
    {
        _logger = logger;
    }


    [HttpGet("{id}", Name = "getClientePorId")]
    public IActionResult get(int id)
    {
        var cliente = new Cliente();
        cliente.CarregarCliente(id);
        return Ok(cliente);
    }

    [HttpGet(Name = "getClientes")]
    public IActionResult getTodosClientes()
    {
        var clientes = Cliente.CarregarTodosClientes();
        return Ok(clientes);
    }

    [HttpDelete(Name = "deleteCliente")]
    public IActionResult delete(int id)
    {
        var cliente = new Cliente();
        cliente.ExcluirCliente(id);

        return NoContent();
    }

    [HttpPost(Name = "IncluirCliente")]
    public IActionResult Post([FromBody] Cliente dados)
    {

        if (dados == null)
        {
            return BadRequest("Objeto inválido");
        }
        dados.Salvardados();

        return Ok();
    }

    [HttpPut(Name = "AlterarCliente")]
    public IActionResult Put([FromBody] Cliente dados)
    {

        if (dados == null)
        {
            return BadRequest("Objeto inválido");
        }
        dados.Alterardados();

        return Ok();
    }

    [HttpGet("buscarPorNome")]
    public IActionResult BuscarPorNome(string nome)
    {
        string connectionString = "Server=127.0.0.1;Port=5432;User Id=postgres;Password=root;Database=oficina;";
        List<Cliente> clientes = new List<Cliente>();

        using (var connection = new NpgsqlConnection(connectionString))
        {
            connection.Open();
            string sql = "SELECT * FROM cliente WHERE nome LIKE @nome";
            using (var command = new NpgsqlCommand(sql, connection))
            {
                command.Parameters.AddWithValue("@nome", "%" + nome + "%");
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        clientes.Add(new Cliente
                        {
                            Id = reader.GetInt32(0),
                            Nome = reader.GetString(1),
                            Endereco = reader.GetString(2),
                            Telefone = reader.GetString(3)
                        });
                    }
                }
            }
        }

        return Ok(clientes);
    }

    [HttpGet("buscarPorDocumento")]
    public IActionResult BuscarPorDocumento(string documento)
    {
        if (string.IsNullOrWhiteSpace(documento))
        {
            return BadRequest("Documento não informado");
        }

        var cliente = Cliente.CarregarPorDocumento(documento);

        if (cliente == null)
        {
            return NotFound("Cliente não encontrado");
        }

        return Ok(cliente);
    }



}